--
-- PostgreSQL database dump
--

\restrict hx5ucWq64tIXNf5akPG9OwIm46jEDoRV7btIvLktyPVo6xTLueEztlSIkdzdS5W

-- Dumped from database version 17.9 (Debian 17.9-1.pgdg12+1)
-- Dumped by pg_dump version 17.9 (Debian 17.9-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: attachments; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.attachments (
    id bigint NOT NULL,
    entity_type character varying(20) NOT NULL,
    entity_id bigint NOT NULL,
    filename character varying(500) NOT NULL,
    file_path character varying(1000) NOT NULL,
    file_size bigint NOT NULL,
    mime_type character varying(100),
    uploaded_by bigint,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT attachments_entity_type_check CHECK (((entity_type)::text = ANY ((ARRAY['INQUIRY'::character varying, 'TASK'::character varying])::text[])))
);


ALTER TABLE public.attachments OWNER TO breaddesk;

--
-- Name: attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attachments_id_seq OWNER TO breaddesk;

--
-- Name: attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.attachments_id_seq OWNED BY public.attachments.id;


--
-- Name: channel_configs; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.channel_configs (
    id bigint NOT NULL,
    channel_type character varying(50) NOT NULL,
    webhook_url character varying(500),
    auth_token character varying(500),
    is_active boolean DEFAULT true NOT NULL,
    config jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE public.channel_configs OWNER TO breaddesk;

--
-- Name: channel_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.channel_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.channel_configs_id_seq OWNER TO breaddesk;

--
-- Name: channel_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.channel_configs_id_seq OWNED BY public.channel_configs.id;


--
-- Name: channel_messages; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.channel_messages (
    id bigint NOT NULL,
    channel_type character varying(20) NOT NULL,
    source character varying(200) NOT NULL,
    content text NOT NULL,
    sender_info jsonb,
    channel_metadata jsonb,
    inquiry_id bigint,
    created_at timestamp without time zone NOT NULL,
    processed_at timestamp without time zone,
    processed boolean DEFAULT false NOT NULL
);


ALTER TABLE public.channel_messages OWNER TO breaddesk;

--
-- Name: TABLE channel_messages; Type: COMMENT; Schema: public; Owner: breaddesk
--

COMMENT ON TABLE public.channel_messages IS 'Unified incoming messages from all channels';


--
-- Name: COLUMN channel_messages.channel_type; Type: COMMENT; Schema: public; Owner: breaddesk
--

COMMENT ON COLUMN public.channel_messages.channel_type IS 'EMAIL, WEB_CHAT, KAKAO, TELEGRAM, WEBHOOK';


--
-- Name: COLUMN channel_messages.source; Type: COMMENT; Schema: public; Owner: breaddesk
--

COMMENT ON COLUMN public.channel_messages.source IS 'Channel-specific identifier (e.g., slack:C12345)';


--
-- Name: COLUMN channel_messages.sender_info; Type: COMMENT; Schema: public; Owner: breaddesk
--

COMMENT ON COLUMN public.channel_messages.sender_info IS 'JSON: {name, email, userId}';


--
-- Name: COLUMN channel_messages.channel_metadata; Type: COMMENT; Schema: public; Owner: breaddesk
--

COMMENT ON COLUMN public.channel_messages.channel_metadata IS 'Channel-specific metadata for replies';


--
-- Name: channel_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.channel_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.channel_messages_id_seq OWNER TO breaddesk;

--
-- Name: channel_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.channel_messages_id_seq OWNED BY public.channel_messages.id;


--
-- Name: csat_surveys; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.csat_surveys (
    id bigint NOT NULL,
    inquiry_id bigint NOT NULL,
    token character varying(255) NOT NULL,
    rating integer,
    feedback text,
    sent_at timestamp without time zone NOT NULL,
    responded_at timestamp without time zone,
    responded boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone NOT NULL,
    CONSTRAINT csat_surveys_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


ALTER TABLE public.csat_surveys OWNER TO breaddesk;

--
-- Name: TABLE csat_surveys; Type: COMMENT; Schema: public; Owner: breaddesk
--

COMMENT ON TABLE public.csat_surveys IS 'Customer satisfaction surveys sent after inquiry resolution';


--
-- Name: COLUMN csat_surveys.token; Type: COMMENT; Schema: public; Owner: breaddesk
--

COMMENT ON COLUMN public.csat_surveys.token IS 'Public access token for survey (UUID)';


--
-- Name: COLUMN csat_surveys.rating; Type: COMMENT; Schema: public; Owner: breaddesk
--

COMMENT ON COLUMN public.csat_surveys.rating IS '1-5 star rating';


--
-- Name: csat_surveys_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.csat_surveys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.csat_surveys_id_seq OWNER TO breaddesk;

--
-- Name: csat_surveys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.csat_surveys_id_seq OWNED BY public.csat_surveys.id;


--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.flyway_schema_history OWNER TO breaddesk;

--
-- Name: inquiries; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.inquiries (
    id bigint NOT NULL,
    channel character varying(50) NOT NULL,
    channel_meta jsonb,
    sender_name character varying(100) NOT NULL,
    sender_email character varying(200),
    message text NOT NULL,
    ai_response text,
    ai_confidence real,
    status character varying(20) DEFAULT 'OPEN'::character varying NOT NULL,
    task_id bigint,
    resolved_by character varying(10),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    resolved_at timestamp without time zone,
    team_id bigint,
    CONSTRAINT inquiries_resolved_by_check CHECK (((resolved_by)::text = ANY ((ARRAY['AI'::character varying, 'HUMAN'::character varying])::text[]))),
    CONSTRAINT inquiries_status_check CHECK (((status)::text = ANY ((ARRAY['OPEN'::character varying, 'AI_ANSWERED'::character varying, 'ESCALATED'::character varying, 'RESOLVED'::character varying, 'CLOSED'::character varying])::text[])))
);


ALTER TABLE public.inquiries OWNER TO breaddesk;

--
-- Name: COLUMN inquiries.task_id; Type: COMMENT; Schema: public; Owner: breaddesk
--

COMMENT ON COLUMN public.inquiries.task_id IS 'Linked task when inquiry is escalated';


--
-- Name: inquiries_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.inquiries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inquiries_id_seq OWNER TO breaddesk;

--
-- Name: inquiries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.inquiries_id_seq OWNED BY public.inquiries.id;


--
-- Name: inquiry_messages; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.inquiry_messages (
    id bigint NOT NULL,
    inquiry_id bigint NOT NULL,
    role character varying(10) NOT NULL,
    message text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    sentiment character varying(20),
    CONSTRAINT inquiry_messages_role_check CHECK (((role)::text = ANY ((ARRAY['USER'::character varying, 'AI'::character varying, 'AGENT'::character varying])::text[])))
);


ALTER TABLE public.inquiry_messages OWNER TO breaddesk;

--
-- Name: COLUMN inquiry_messages.sentiment; Type: COMMENT; Schema: public; Owner: breaddesk
--

COMMENT ON COLUMN public.inquiry_messages.sentiment IS 'POSITIVE, NEUTRAL, NEGATIVE, ANGRY';


--
-- Name: inquiry_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.inquiry_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inquiry_messages_id_seq OWNER TO breaddesk;

--
-- Name: inquiry_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.inquiry_messages_id_seq OWNED BY public.inquiry_messages.id;


--
-- Name: knowledge_connectors; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.knowledge_connectors (
    id bigint NOT NULL,
    source_type character varying(50) NOT NULL,
    config jsonb NOT NULL,
    sync_interval_min integer DEFAULT 60 NOT NULL,
    last_synced_at timestamp without time zone,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    name character varying(200)
);


ALTER TABLE public.knowledge_connectors OWNER TO breaddesk;

--
-- Name: knowledge_connectors_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.knowledge_connectors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knowledge_connectors_id_seq OWNER TO breaddesk;

--
-- Name: knowledge_connectors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.knowledge_connectors_id_seq OWNED BY public.knowledge_connectors.id;


--
-- Name: knowledge_documents; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.knowledge_documents (
    id bigint NOT NULL,
    source character varying(50) NOT NULL,
    source_id character varying(200),
    title character varying(500) NOT NULL,
    content text,
    url character varying(1000),
    tags jsonb,
    embedding public.vector(768),
    synced_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    connector_id bigint,
    chunk_index integer DEFAULT 0
);


ALTER TABLE public.knowledge_documents OWNER TO breaddesk;

--
-- Name: knowledge_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.knowledge_documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knowledge_documents_id_seq OWNER TO breaddesk;

--
-- Name: knowledge_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.knowledge_documents_id_seq OWNED BY public.knowledge_documents.id;


--
-- Name: members; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.members (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(200) NOT NULL,
    password_hash character varying(200),
    role character varying(20) DEFAULT 'AGENT'::character varying NOT NULL,
    skills jsonb,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT members_role_check CHECK (((role)::text = ANY ((ARRAY['AGENT'::character varying, 'ADMIN'::character varying])::text[])))
);


ALTER TABLE public.members OWNER TO breaddesk;

--
-- Name: members_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.members_id_seq OWNER TO breaddesk;

--
-- Name: members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.members_id_seq OWNED BY public.members.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    member_id bigint NOT NULL,
    type character varying(50) NOT NULL,
    title character varying(300) NOT NULL,
    message text,
    link character varying(500),
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.notifications OWNER TO breaddesk;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO breaddesk;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: personal_notes; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.personal_notes (
    id bigint NOT NULL,
    member_id bigint NOT NULL,
    content text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.personal_notes OWNER TO breaddesk;

--
-- Name: personal_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.personal_notes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.personal_notes_id_seq OWNER TO breaddesk;

--
-- Name: personal_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.personal_notes_id_seq OWNED BY public.personal_notes.id;


--
-- Name: prompt_configs; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.prompt_configs (
    id bigint NOT NULL,
    key character varying(100) NOT NULL,
    name character varying(100) NOT NULL,
    prompt_template text NOT NULL,
    description character varying(500),
    active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.prompt_configs OWNER TO breaddesk;

--
-- Name: TABLE prompt_configs; Type: COMMENT; Schema: public; Owner: breaddesk
--

COMMENT ON TABLE public.prompt_configs IS 'AI prompt templates for different features';


--
-- Name: COLUMN prompt_configs.key; Type: COMMENT; Schema: public; Owner: breaddesk
--

COMMENT ON COLUMN public.prompt_configs.key IS 'Unique key identifier (e.g., ai_answer, classification)';


--
-- Name: COLUMN prompt_configs.prompt_template; Type: COMMENT; Schema: public; Owner: breaddesk
--

COMMENT ON COLUMN public.prompt_configs.prompt_template IS 'Prompt template with placeholders';


--
-- Name: prompt_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.prompt_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.prompt_configs_id_seq OWNER TO breaddesk;

--
-- Name: prompt_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.prompt_configs_id_seq OWNED BY public.prompt_configs.id;


--
-- Name: reply_templates; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.reply_templates (
    id bigint NOT NULL,
    title character varying(200) NOT NULL,
    category character varying(100),
    content text NOT NULL,
    usage_count integer DEFAULT 0 NOT NULL,
    created_by bigint,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.reply_templates OWNER TO breaddesk;

--
-- Name: reply_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.reply_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reply_templates_id_seq OWNER TO breaddesk;

--
-- Name: reply_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.reply_templates_id_seq OWNED BY public.reply_templates.id;


--
-- Name: sla_rules; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.sla_rules (
    id bigint NOT NULL,
    urgency character varying(20) NOT NULL,
    response_minutes integer NOT NULL,
    resolve_minutes integer NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    CONSTRAINT sla_rules_urgency_check CHECK (((urgency)::text = ANY ((ARRAY['LOW'::character varying, 'NORMAL'::character varying, 'HIGH'::character varying, 'CRITICAL'::character varying])::text[])))
);


ALTER TABLE public.sla_rules OWNER TO breaddesk;

--
-- Name: sla_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.sla_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sla_rules_id_seq OWNER TO breaddesk;

--
-- Name: sla_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.sla_rules_id_seq OWNED BY public.sla_rules.id;


--
-- Name: task_checklists; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.task_checklists (
    id bigint NOT NULL,
    task_id bigint NOT NULL,
    item_text character varying(500) NOT NULL,
    is_done boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.task_checklists OWNER TO breaddesk;

--
-- Name: task_checklists_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.task_checklists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_checklists_id_seq OWNER TO breaddesk;

--
-- Name: task_checklists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.task_checklists_id_seq OWNED BY public.task_checklists.id;


--
-- Name: task_comments; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.task_comments (
    id bigint NOT NULL,
    task_id bigint NOT NULL,
    author_id bigint,
    content text NOT NULL,
    is_internal boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.task_comments OWNER TO breaddesk;

--
-- Name: task_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.task_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_comments_id_seq OWNER TO breaddesk;

--
-- Name: task_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.task_comments_id_seq OWNED BY public.task_comments.id;


--
-- Name: task_guides; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.task_guides (
    id bigint NOT NULL,
    task_id bigint NOT NULL,
    checklist_json jsonb,
    related_docs_json jsonb,
    similar_tasks_json jsonb,
    guidelines text,
    estimated_hours real,
    generated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.task_guides OWNER TO breaddesk;

--
-- Name: task_guides_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.task_guides_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_guides_id_seq OWNER TO breaddesk;

--
-- Name: task_guides_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.task_guides_id_seq OWNED BY public.task_guides.id;


--
-- Name: task_holds; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.task_holds (
    id bigint NOT NULL,
    task_id bigint NOT NULL,
    reason text NOT NULL,
    started_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ended_at timestamp without time zone,
    sla_paused_minutes integer DEFAULT 0
);


ALTER TABLE public.task_holds OWNER TO breaddesk;

--
-- Name: task_holds_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.task_holds_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_holds_id_seq OWNER TO breaddesk;

--
-- Name: task_holds_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.task_holds_id_seq OWNED BY public.task_holds.id;


--
-- Name: task_logs; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.task_logs (
    id bigint NOT NULL,
    task_id bigint NOT NULL,
    action character varying(50) NOT NULL,
    actor_id bigint,
    details jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.task_logs OWNER TO breaddesk;

--
-- Name: task_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.task_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_logs_id_seq OWNER TO breaddesk;

--
-- Name: task_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.task_logs_id_seq OWNED BY public.task_logs.id;


--
-- Name: task_relations; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.task_relations (
    id bigint NOT NULL,
    source_task_id bigint NOT NULL,
    target_task_id bigint NOT NULL,
    relation_type character varying(20) NOT NULL,
    CONSTRAINT task_relations_relation_type_check CHECK (((relation_type)::text = ANY ((ARRAY['BLOCKS'::character varying, 'RELATED'::character varying, 'DUPLICATE'::character varying])::text[])))
);


ALTER TABLE public.task_relations OWNER TO breaddesk;

--
-- Name: task_relations_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.task_relations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_relations_id_seq OWNER TO breaddesk;

--
-- Name: task_relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.task_relations_id_seq OWNED BY public.task_relations.id;


--
-- Name: task_tags; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.task_tags (
    id bigint NOT NULL,
    task_id bigint NOT NULL,
    tag character varying(100) NOT NULL
);


ALTER TABLE public.task_tags OWNER TO breaddesk;

--
-- Name: task_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.task_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_tags_id_seq OWNER TO breaddesk;

--
-- Name: task_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.task_tags_id_seq OWNED BY public.task_tags.id;


--
-- Name: task_transfers; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.task_transfers (
    id bigint NOT NULL,
    task_id bigint NOT NULL,
    from_member_id bigint,
    to_member_id bigint,
    reason text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.task_transfers OWNER TO breaddesk;

--
-- Name: task_transfers_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.task_transfers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_transfers_id_seq OWNER TO breaddesk;

--
-- Name: task_transfers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.task_transfers_id_seq OWNED BY public.task_transfers.id;


--
-- Name: task_watchers; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.task_watchers (
    id bigint NOT NULL,
    task_id bigint NOT NULL,
    member_id bigint NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.task_watchers OWNER TO breaddesk;

--
-- Name: task_watchers_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.task_watchers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_watchers_id_seq OWNER TO breaddesk;

--
-- Name: task_watchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.task_watchers_id_seq OWNED BY public.task_watchers.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.tasks (
    id bigint NOT NULL,
    title character varying(500) NOT NULL,
    description text,
    type character varying(50) DEFAULT 'GENERAL'::character varying NOT NULL,
    urgency character varying(20) DEFAULT 'NORMAL'::character varying NOT NULL,
    status character varying(20) DEFAULT 'WAITING'::character varying NOT NULL,
    requester_name character varying(100),
    requester_email character varying(200),
    assignee_id bigint,
    inquiry_id bigint,
    ai_summary text,
    due_date date,
    estimated_hours real,
    actual_hours real,
    sla_response_deadline timestamp without time zone,
    sla_resolve_deadline timestamp without time zone,
    sla_responded_at timestamp without time zone,
    sla_response_breached boolean DEFAULT false NOT NULL,
    sla_resolve_breached boolean DEFAULT false NOT NULL,
    jira_issue_key character varying(50),
    jira_issue_url character varying(500),
    transfer_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    team_id bigint,
    CONSTRAINT tasks_status_check CHECK (((status)::text = ANY ((ARRAY['WAITING'::character varying, 'IN_PROGRESS'::character varying, 'PENDING'::character varying, 'REVIEW'::character varying, 'DONE'::character varying])::text[]))),
    CONSTRAINT tasks_urgency_check CHECK (((urgency)::text = ANY ((ARRAY['LOW'::character varying, 'NORMAL'::character varying, 'HIGH'::character varying, 'CRITICAL'::character varying])::text[])))
);


ALTER TABLE public.tasks OWNER TO breaddesk;

--
-- Name: COLUMN tasks.sla_response_deadline; Type: COMMENT; Schema: public; Owner: breaddesk
--

COMMENT ON COLUMN public.tasks.sla_response_deadline IS 'SLA deadline for first response';


--
-- Name: COLUMN tasks.sla_resolve_deadline; Type: COMMENT; Schema: public; Owner: breaddesk
--

COMMENT ON COLUMN public.tasks.sla_resolve_deadline IS 'SLA deadline for resolution';


--
-- Name: COLUMN tasks.sla_responded_at; Type: COMMENT; Schema: public; Owner: breaddesk
--

COMMENT ON COLUMN public.tasks.sla_responded_at IS 'Actual first response time';


--
-- Name: COLUMN tasks.sla_response_breached; Type: COMMENT; Schema: public; Owner: breaddesk
--

COMMENT ON COLUMN public.tasks.sla_response_breached IS 'Whether response SLA was breached';


--
-- Name: COLUMN tasks.sla_resolve_breached; Type: COMMENT; Schema: public; Owner: breaddesk
--

COMMENT ON COLUMN public.tasks.sla_resolve_breached IS 'Whether resolve SLA was breached';


--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO breaddesk;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: team_members; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.team_members (
    id bigint NOT NULL,
    team_id bigint NOT NULL,
    member_id bigint NOT NULL,
    role character varying(50) DEFAULT 'MEMBER'::character varying,
    joined_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.team_members OWNER TO breaddesk;

--
-- Name: team_members_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.team_members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.team_members_id_seq OWNER TO breaddesk;

--
-- Name: team_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.team_members_id_seq OWNED BY public.team_members.id;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: breaddesk
--

CREATE TABLE public.teams (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.teams OWNER TO breaddesk;

--
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: breaddesk
--

CREATE SEQUENCE public.teams_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.teams_id_seq OWNER TO breaddesk;

--
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: breaddesk
--

ALTER SEQUENCE public.teams_id_seq OWNED BY public.teams.id;


--
-- Name: attachments id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.attachments ALTER COLUMN id SET DEFAULT nextval('public.attachments_id_seq'::regclass);


--
-- Name: channel_configs id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.channel_configs ALTER COLUMN id SET DEFAULT nextval('public.channel_configs_id_seq'::regclass);


--
-- Name: channel_messages id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.channel_messages ALTER COLUMN id SET DEFAULT nextval('public.channel_messages_id_seq'::regclass);


--
-- Name: csat_surveys id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.csat_surveys ALTER COLUMN id SET DEFAULT nextval('public.csat_surveys_id_seq'::regclass);


--
-- Name: inquiries id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.inquiries ALTER COLUMN id SET DEFAULT nextval('public.inquiries_id_seq'::regclass);


--
-- Name: inquiry_messages id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.inquiry_messages ALTER COLUMN id SET DEFAULT nextval('public.inquiry_messages_id_seq'::regclass);


--
-- Name: knowledge_connectors id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.knowledge_connectors ALTER COLUMN id SET DEFAULT nextval('public.knowledge_connectors_id_seq'::regclass);


--
-- Name: knowledge_documents id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.knowledge_documents ALTER COLUMN id SET DEFAULT nextval('public.knowledge_documents_id_seq'::regclass);


--
-- Name: members id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.members ALTER COLUMN id SET DEFAULT nextval('public.members_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: personal_notes id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.personal_notes ALTER COLUMN id SET DEFAULT nextval('public.personal_notes_id_seq'::regclass);


--
-- Name: prompt_configs id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.prompt_configs ALTER COLUMN id SET DEFAULT nextval('public.prompt_configs_id_seq'::regclass);


--
-- Name: reply_templates id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.reply_templates ALTER COLUMN id SET DEFAULT nextval('public.reply_templates_id_seq'::regclass);


--
-- Name: sla_rules id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.sla_rules ALTER COLUMN id SET DEFAULT nextval('public.sla_rules_id_seq'::regclass);


--
-- Name: task_checklists id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_checklists ALTER COLUMN id SET DEFAULT nextval('public.task_checklists_id_seq'::regclass);


--
-- Name: task_comments id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_comments ALTER COLUMN id SET DEFAULT nextval('public.task_comments_id_seq'::regclass);


--
-- Name: task_guides id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_guides ALTER COLUMN id SET DEFAULT nextval('public.task_guides_id_seq'::regclass);


--
-- Name: task_holds id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_holds ALTER COLUMN id SET DEFAULT nextval('public.task_holds_id_seq'::regclass);


--
-- Name: task_logs id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_logs ALTER COLUMN id SET DEFAULT nextval('public.task_logs_id_seq'::regclass);


--
-- Name: task_relations id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_relations ALTER COLUMN id SET DEFAULT nextval('public.task_relations_id_seq'::regclass);


--
-- Name: task_tags id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_tags ALTER COLUMN id SET DEFAULT nextval('public.task_tags_id_seq'::regclass);


--
-- Name: task_transfers id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_transfers ALTER COLUMN id SET DEFAULT nextval('public.task_transfers_id_seq'::regclass);


--
-- Name: task_watchers id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_watchers ALTER COLUMN id SET DEFAULT nextval('public.task_watchers_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: team_members id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.team_members ALTER COLUMN id SET DEFAULT nextval('public.team_members_id_seq'::regclass);


--
-- Name: teams id; Type: DEFAULT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.teams ALTER COLUMN id SET DEFAULT nextval('public.teams_id_seq'::regclass);


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.attachments (id, entity_type, entity_id, filename, file_path, file_size, mime_type, uploaded_by, created_at) FROM stdin;
\.


--
-- Data for Name: channel_configs; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.channel_configs (id, channel_type, webhook_url, auth_token, is_active, config, created_at, updated_at) FROM stdin;
2	teams	\N	\N	f	{"icon": "teams", "displayName": "Microsoft Teams"}	2026-03-30 23:47:05.85821	\N
3	email	\N	\N	f	{"icon": "email", "displayName": "Email"}	2026-03-30 23:47:05.85821	\N
1	slack	\N	\N	f	{"icon": "slack", "displayName": "Slack"}	2026-03-30 23:47:05.85821	2026-03-31 21:38:44.316334
\.


--
-- Data for Name: channel_messages; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.channel_messages (id, channel_type, source, content, sender_info, channel_metadata, inquiry_id, created_at, processed_at, processed) FROM stdin;
\.


--
-- Data for Name: csat_surveys; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.csat_surveys (id, inquiry_id, token, rating, feedback, sent_at, responded_at, responded, created_at) FROM stdin;
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	init schema	SQL	V1__init_schema.sql	2063729380	breaddesk	2026-03-30 23:47:05.048234	222	t
2	2	knowledge rag enhancements	SQL	V2__knowledge_rag_enhancements.sql	933777792	breaddesk	2026-03-30 23:47:05.790711	15	t
3	3	channel configs	SQL	V3__channel_configs.sql	-168511726	breaddesk	2026-03-30 23:47:05.846769	19	t
4	4	phase2 task mgmt	SQL	V4__phase2_task_mgmt.sql	669670524	breaddesk	2026-04-02 10:53:08.502474	119	t
5	5	phase3 knowledge sla	SQL	V5__phase3_knowledge_sla.sql	-1390323820	breaddesk	2026-04-02 10:53:09.000021	150	t
6	6	phase4 channels	SQL	V6__phase4_channels.sql	1539638907	breaddesk	2026-04-02 10:53:09.256312	136	t
7	7	phase5 features	SQL	V7__phase5_features.sql	1265995080	breaddesk	2026-04-02 10:53:09.700054	140	t
\.


--
-- Data for Name: inquiries; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.inquiries (id, channel, channel_meta, sender_name, sender_email, message, ai_response, ai_confidence, status, task_id, resolved_by, created_at, resolved_at, team_id) FROM stdin;
1	manual	\N	테스트 고객	\N	결제가 안 됩니다. 확인 부탁드립니다.	\N	\N	RESOLVED	1	\N	2026-04-03 20:39:12.858246	2026-04-03 22:56:27.991544	\N
2	CHAT	\N	김민수	\N	배송이 아직 안 왔는데 언제 오나요? 주문번호는 ORD-2024-1234입니다.	안녕하세요! 주문번호 ORD-2024-1234에 대한 배송 상태를 확인하려면 담당자에게 문의해야 합니다. 정확한 배송 일정은 고객 지원팀이 확인해 드릴 수 있습니다. \n\n감사합니다!	0.6	ESCALATED	2	\N	2026-04-04 01:05:33.675387	\N	\N
3	CHAT	\N	이서연	\N	환불 요청합니다. 상품이 불량이에요. 사진도 첨부하고 싶은데 어떻게 하나요?	환불 요청을 원하신다면, 고객센터에 직접 문의하셔야 합니다. 사진을 첨부하여 불량 상품에 대한 증빙을 제출할 수 있습니다. 고객센터에 연락하실 때 사진 파일을 함께 전송해 주시면 됩니다. \n\n자세한 절차는 고객센터에 문의해 주시기 바랍니다. 감사합니다!	0.85	AI_ANSWERED	\N	AI	2026-04-04 01:05:37.41017	\N	\N
4	CHAT	\N	박준호	\N	회원 탈퇴하고 싶습니다. 개인정보 삭제도 같이 해주세요.	회원 탈퇴를 원하시는 경우, 고객센터에 직접 문의하셔야 합니다. 개인정보 삭제 요청도 함께 진행해드릴 수 있습니다. \n\n자세한 안내를 위해 고객센터에 연락해 주시기 바랍니다. \n\n관련 문서: [고객센터 연락처 URL]	0.85	AI_ANSWERED	\N	AI	2026-04-04 01:05:41.377585	\N	\N
5	CHAT	\N	최유진	\N	구매한 상품의 사이즈 교환이 가능한가요? M사이즈에서 L로 변경하고 싶어요.	구매한 상품의 사이즈 교환 가능 여부는 해당 상품의 교환 정책에 따라 다를 수 있습니다. 일반적으로 사이즈 교환이 가능하지만, 정확한 사항은 담당자에게 확인해야 합니다.\n\n교환 요청을 원하시면 고객센터에 문의하시거나, 구매하신 플랫폼의 교환 절차를 확인해 주시기 바랍니다. \n\n도움이 필요하시면 언제든지 말씀해 주세요!	0.6	ESCALATED	3	\N	2026-04-04 01:05:44.608264	\N	\N
6	CHAT	\N	정하늘	\N	앱이 자꾸 튕겨요. 아이폰 16에서 최신 버전 사용 중인데 로그인만 하면 크래시가 납니다.	앱이 튕기는 문제는 여러 가지 원인으로 발생할 수 있습니다. 우선, 다음 몇 가지를 시도해 보시기 바랍니다:\n\n1. 앱을 최신 버전으로 업데이트했는지 확인하세요.\n2. 아이폰의 iOS 버전이 최신인지 확인하고, 필요 시 업데이트하세요.\n3. 앱을 삭제한 후 재설치해 보세요.\n4. 기기를 재부팅해 보세요.\n\n이러한 방법으로도 문제가 해결되지 않는다면, 보다 자세한 원인 분석이 필요할 수 있습니다. 이 경우 담당자에게 확인해 보도록 하겠습니다.\n\n관련 문서: [URL]	0.6	ESCALATED	4	\N	2026-04-04 01:05:48.881624	\N	\N
7	WEBCHAT	{"sessionId": "4fc52f0d-046e-4d54-9704-06c2ce253de5"}	웹챗 사용자	\N	배송 조회 하고 싶어요	배송 조회를 원하신다면, 주문 확인을 위해 주문 번호를 제공해 주시면 더 정확한 정보를 안내해 드릴 수 있습니다. 또는, 고객센터에 직접 문의하시면 상세한 도움을 받으실 수 있습니다. 감사합니다!	0.85	AI_ANSWERED	\N	AI	2026-04-04 01:47:07.691574	\N	\N
8	WEBCHAT	{"sessionId": "b1355c24-3521-4200-93b4-2686a31d19fb"}	웹챗 사용자	\N	구매한 노트북 화면에 불량 화소가 있어요. 교환 가능한가요?	불량 화소로 인한 교환 가능 여부는 구입하신 제품의 보증 정책에 따라 다릅니다. 일반적으로 제조사나 판매자의 보증 기준에 따라 불량 화소의 개수에 따라 교환이 가능할 수 있습니다. 구체적인 교환 절차나 조건에 대해서는 담당자에게 확인이 필요합니다. \n\n관련된 정보를 원하시면, 구매하신 곳의 고객 지원 센터에 문의하시기를 권장합니다.	0.5	OPEN	\N	\N	2026-04-04 01:50:29.145356	\N	\N
\.


--
-- Data for Name: inquiry_messages; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.inquiry_messages (id, inquiry_id, role, message, created_at, sentiment) FROM stdin;
1	1	AGENT	결제 오류 확인 중입니다.	2026-04-03 20:42:11.043386	\N
2	2	AI	안녕하세요! 주문번호 ORD-2024-1234에 대한 배송 상태를 확인하려면 담당자에게 문의해야 합니다. 정확한 배송 일정은 고객 지원팀이 확인해 드릴 수 있습니다. \n\n감사합니다!	2026-04-04 01:05:36.244777	\N
3	3	AI	환불 요청을 원하신다면, 고객센터에 직접 문의하셔야 합니다. 사진을 첨부하여 불량 상품에 대한 증빙을 제출할 수 있습니다. 고객센터에 연락하실 때 사진 파일을 함께 전송해 주시면 됩니다. \n\n자세한 절차는 고객센터에 문의해 주시기 바랍니다. 감사합니다!	2026-04-04 01:05:40.251051	\N
4	4	AI	회원 탈퇴를 원하시는 경우, 고객센터에 직접 문의하셔야 합니다. 개인정보 삭제 요청도 함께 진행해드릴 수 있습니다. \n\n자세한 안내를 위해 고객센터에 연락해 주시기 바랍니다. \n\n관련 문서: [고객센터 연락처 URL]	2026-04-04 01:05:43.483046	\N
5	5	AI	구매한 상품의 사이즈 교환 가능 여부는 해당 상품의 교환 정책에 따라 다를 수 있습니다. 일반적으로 사이즈 교환이 가능하지만, 정확한 사항은 담당자에게 확인해야 합니다.\n\n교환 요청을 원하시면 고객센터에 문의하시거나, 구매하신 플랫폼의 교환 절차를 확인해 주시기 바랍니다. \n\n도움이 필요하시면 언제든지 말씀해 주세요!	2026-04-04 01:05:47.741243	\N
6	6	AI	앱이 튕기는 문제는 여러 가지 원인으로 발생할 수 있습니다. 우선, 다음 몇 가지를 시도해 보시기 바랍니다:\n\n1. 앱을 최신 버전으로 업데이트했는지 확인하세요.\n2. 아이폰의 iOS 버전이 최신인지 확인하고, 필요 시 업데이트하세요.\n3. 앱을 삭제한 후 재설치해 보세요.\n4. 기기를 재부팅해 보세요.\n\n이러한 방법으로도 문제가 해결되지 않는다면, 보다 자세한 원인 분석이 필요할 수 있습니다. 이 경우 담당자에게 확인해 보도록 하겠습니다.\n\n관련 문서: [URL]	2026-04-04 01:05:51.873756	\N
7	7	USER	배송 조회 하고 싶어요	2026-04-04 01:47:07.715855	\N
8	7	AI	배송 조회를 원하신다면, 주문 확인을 위해 주문 번호를 제공해 주시면 더 정확한 정보를 안내해 드릴 수 있습니다. 또는, 고객센터에 직접 문의하시면 상세한 도움을 받으실 수 있습니다. 감사합니다!	2026-04-04 01:47:12.711834	\N
9	8	USER	구매한 노트북 화면에 불량 화소가 있어요. 교환 가능한가요?	2026-04-04 01:50:29.148453	\N
10	8	AI	불량 화소로 인한 교환 가능 여부는 구입하신 제품의 보증 정책에 따라 다릅니다. 일반적으로 제조사나 판매자의 보증 기준에 따라 불량 화소의 개수에 따라 교환이 가능할 수 있습니다. 구체적인 교환 절차나 조건에 대해서는 담당자에게 확인이 필요합니다. \n\n관련된 정보를 원하시면, 구매하신 곳의 고객 지원 센터에 문의하시기를 권장합니다.	2026-04-04 01:50:32.093704	\N
\.


--
-- Data for Name: knowledge_connectors; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.knowledge_connectors (id, source_type, config, sync_interval_min, last_synced_at, is_active, created_at, name) FROM stdin;
\.


--
-- Data for Name: knowledge_documents; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.knowledge_documents (id, source, source_id, title, content, url, tags, embedding, synced_at, created_at, connector_id, chunk_index) FROM stdin;
\.


--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.members (id, name, email, password_hash, role, skills, is_active, created_at, updated_at) FROM stdin;
1	관리자	admin@breadlab.com	$2b$12$y03J29h7Wky77mgJ4a2ZVepBR7Lqb./p6Gr0C6/0dswXfORDoLvA.	ADMIN	\N	t	2026-03-31 00:10:02.918458	2026-03-31 00:10:02.918458
2	데모 사용자	demo@breaddesk.com	$2b$12$8chVMc4pa6xv0gzoTVZ4LOMVv5sFhl2mYxr4b0GS/Z6OotmX6D5la	AGENT	[]	t	2026-03-31 21:27:48.502398	2026-03-31 21:27:48.502398
3	테스트 유저	testuser@breaddesk.com	$2a$10$.WawHgp6LgWe5vc1ZtyyeOa8lH1zzNiYXXhdwtXOSij1dbLtisM2y	AGENT	\N	t	2026-04-04 02:20:21.897831	2026-04-04 02:20:21.897831
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.notifications (id, member_id, type, title, message, link, is_read, created_at) FROM stdin;
1	1	ESCALATION	새 에스컬레이션: 결제가 안 됩니다. 확인 부탁드립니다.	문의 #1가 업무 #1로 에스컬레이션되었습니다. (Urgency: NORMAL)	/tasks/1	f	2026-04-03 20:39:12.96955
2	1	SLA_BREACHED	[SLA 에스컬레이션] [에스컬레이션] 결제가 안 됩니다. 확인 부탁드립니다.	업무 #1의 응답 SLA가 위반되었습니다. 담당자: 미배정	/tasks/1	f	2026-04-04 00:39:56.397928
3	1	ESCALATION	새 에스컬레이션: 배송이 아직 안 왔는데 언제 오나요? 주문번호는 ORD-2024-1234입니다.	문의 #2가 업무 #2로 에스컬레이션되었습니다. (Urgency: NORMAL)	/tasks/2	f	2026-04-04 01:05:36.271543
4	1	ESCALATION	새 에스컬레이션: 구매한 상품의 사이즈 교환이 가능한가요? M사이즈에서 L로 변경하고 싶어요.	문의 #5가 업무 #3로 에스컬레이션되었습니다. (Urgency: NORMAL)	/tasks/3	f	2026-04-04 01:05:47.756476
5	1	ESCALATION	새 에스컬레이션: 앱이 자꾸 튕겨요. 아이폰 16에서 최신 버전 사용 중인데 로그인만 하면 크래시가 납니다.	문의 #6가 업무 #4로 에스컬레이션되었습니다. (Urgency: NORMAL)	/tasks/4	f	2026-04-04 01:05:51.88884
\.


--
-- Data for Name: personal_notes; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.personal_notes (id, member_id, content, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: prompt_configs; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.prompt_configs (id, key, name, prompt_template, description, active, created_at, updated_at) FROM stdin;
1	ai_answer	AI Auto Answer	You are a helpful customer support AI. Answer the following question based on the provided knowledge base.\\n\\nQuestion: {question}\\n\\nKnowledge: {knowledge}\\n\\nAnswer:	Default prompt for AI auto-answer feature	t	2026-04-02 10:53:09.832542	2026-04-02 10:53:09.832542
2	classification	Category Classification	Classify the following customer inquiry into one of these categories: TECHNICAL, BILLING, GENERAL, COMPLAINT.\\n\\nInquiry: {message}\\n\\nCategory:	Prompt for automatic category classification	t	2026-04-02 10:53:09.832542	2026-04-02 10:53:09.832542
3	sentiment	Sentiment Analysis	Analyze the sentiment of the following message. Respond with ONLY ONE WORD: POSITIVE, NEUTRAL, NEGATIVE, or ANGRY.\\n\\nMessage: {message}\\n\\nSentiment:	Prompt for sentiment analysis	t	2026-04-02 10:53:09.832542	2026-04-02 10:53:09.832542
4	summary	Conversation Summary	Summarize the following customer support conversation in 2-3 sentences.\\n\\nConversation: {conversation}\\n\\nSummary:	Prompt for generating conversation summaries	t	2026-04-02 10:53:09.832542	2026-04-02 10:53:09.832542
\.


--
-- Data for Name: reply_templates; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.reply_templates (id, title, category, content, usage_count, created_by, created_at, updated_at) FROM stdin;
1	환영 인사	인사	안녕하세요, {{name}}님! 문의해 주셔서 감사합니다.	1	1	2026-03-31 02:21:29.796824	2026-03-31 21:34:06.037722
2	안부인사	인사	안녕	0	1	2026-03-31 21:34:34.065202	2026-03-31 21:34:34.065202
3	또 인사	회원가입	안녕	0	1	2026-03-31 21:36:14.493192	2026-03-31 21:36:14.493192
\.


--
-- Data for Name: sla_rules; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.sla_rules (id, urgency, response_minutes, resolve_minutes, is_active) FROM stdin;
1	CRITICAL	30	240	t
2	HIGH	120	1440	t
3	NORMAL	240	4320	t
4	LOW	1440	7200	t
\.


--
-- Data for Name: task_checklists; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.task_checklists (id, task_id, item_text, is_done, sort_order) FROM stdin;
\.


--
-- Data for Name: task_comments; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.task_comments (id, task_id, author_id, content, is_internal, created_at) FROM stdin;
\.


--
-- Data for Name: task_guides; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.task_guides (id, task_id, checklist_json, related_docs_json, similar_tasks_json, guidelines, estimated_hours, generated_at) FROM stdin;
\.


--
-- Data for Name: task_holds; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.task_holds (id, task_id, reason, started_at, ended_at, sla_paused_minutes) FROM stdin;
\.


--
-- Data for Name: task_logs; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.task_logs (id, task_id, action, actor_id, details, created_at) FROM stdin;
\.


--
-- Data for Name: task_relations; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.task_relations (id, source_task_id, target_task_id, relation_type) FROM stdin;
\.


--
-- Data for Name: task_tags; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.task_tags (id, task_id, tag) FROM stdin;
\.


--
-- Data for Name: task_transfers; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.task_transfers (id, task_id, from_member_id, to_member_id, reason, created_at) FROM stdin;
\.


--
-- Data for Name: task_watchers; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.task_watchers (id, task_id, member_id, created_at) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.tasks (id, title, description, type, urgency, status, requester_name, requester_email, assignee_id, inquiry_id, ai_summary, due_date, estimated_hours, actual_hours, sla_response_deadline, sla_resolve_deadline, sla_responded_at, sla_response_breached, sla_resolve_breached, jira_issue_key, jira_issue_url, transfer_count, created_at, started_at, completed_at, team_id) FROM stdin;
1	[에스컬레이션] 결제가 안 됩니다. 확인 부탁드립니다.	## 원본 문의\n- **채널:** manual\n- **발신자:** 테스트 고객\n- **내용:** 결제가 안 됩니다. 확인 부탁드립니다.\n	ESCALATION	NORMAL	WAITING	테스트 고객	\N	\N	\N	\N	\N	\N	\N	2026-04-04 00:39:12.937573	2026-04-06 20:39:12.937573	\N	t	f	\N	\N	0	2026-04-03 20:39:12.937573	\N	\N	\N
2	[에스컬레이션] 배송이 아직 안 왔는데 언제 오나요? 주문번호는 ORD-2024-1234입니다.	## 원본 문의\n- **채널:** CHAT\n- **발신자:** 김민수\n- **내용:** 배송이 아직 안 왔는데 언제 오나요? 주문번호는 ORD-2024-1234입니다.\n\n## AI 답변 (confidence: 60.0%)\n안녕하세요! 주문번호 ORD-2024-1234에 대한 배송 상태를 확인하려면 담당자에게 문의해야 합니다. 정확한 배송 일정은 고객 지원팀이 확인해 드릴 수 있습니다. \n\n감사합니다!\n	ESCALATION	NORMAL	WAITING	김민수	\N	\N	\N	\N	\N	\N	\N	2026-04-04 05:05:36.251508	2026-04-07 01:05:36.251508	\N	f	f	\N	\N	0	2026-04-04 01:05:36.251508	\N	\N	\N
3	[에스컬레이션] 구매한 상품의 사이즈 교환이 가능한가요? M사이즈에서 L로 변경하고 싶어요.	## 원본 문의\n- **채널:** CHAT\n- **발신자:** 최유진\n- **내용:** 구매한 상품의 사이즈 교환이 가능한가요? M사이즈에서 L로 변경하고 싶어요.\n\n## AI 답변 (confidence: 60.0%)\n구매한 상품의 사이즈 교환 가능 여부는 해당 상품의 교환 정책에 따라 다를 수 있습니다. 일반적으로 사이즈 교환이 가능하지만, 정확한 사항은 담당자에게 확인해야 합니다.\n\n교환 요청을 원하시면 고객센터에 문의하시거나, 구매하신 플랫폼의 교환 절차를 확인해 주시기 바랍니다. \n\n도움이 필요하시면 언제든지 말씀해 주세요!\n	ESCALATION	NORMAL	WAITING	최유진	\N	\N	\N	\N	\N	\N	\N	2026-04-04 05:05:47.745084	2026-04-07 01:05:47.745084	\N	f	f	\N	\N	0	2026-04-04 01:05:47.745084	\N	\N	\N
4	[에스컬레이션] 앱이 자꾸 튕겨요. 아이폰 16에서 최신 버전 사용 중인데 로그인만 하면 크래시가 납니다.	## 원본 문의\n- **채널:** CHAT\n- **발신자:** 정하늘\n- **내용:** 앱이 자꾸 튕겨요. 아이폰 16에서 최신 버전 사용 중인데 로그인만 하면 크래시가 납니다.\n\n## AI 답변 (confidence: 60.0%)\n앱이 튕기는 문제는 여러 가지 원인으로 발생할 수 있습니다. 우선, 다음 몇 가지를 시도해 보시기 바랍니다:\n\n1. 앱을 최신 버전으로 업데이트했는지 확인하세요.\n2. 아이폰의 iOS 버전이 최신인지 확인하고, 필요 시 업데이트하세요.\n3. 앱을 삭제한 후 재설치해 보세요.\n4. 기기를 재부팅해 보세요.\n\n이러한 방법으로도 문제가 해결되지 않는다면, 보다 자세한 원인 분석이 필요할 수 있습니다. 이 경우 담당자에게 확인해 보도록 하겠습니다.\n\n관련 문서: [URL]\n	ESCALATION	NORMAL	WAITING	정하늘	\N	\N	\N	\N	\N	\N	\N	2026-04-04 05:05:51.8775	2026-04-07 01:05:51.8775	\N	f	f	\N	\N	0	2026-04-04 01:05:51.8775	\N	\N	\N
\.


--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.team_members (id, team_id, member_id, role, joined_at) FROM stdin;
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: breaddesk
--

COPY public.teams (id, name, description, is_active, created_at, updated_at) FROM stdin;
1	IT 인프라팀	VPN, 서버, 네트워크 관련	t	2026-04-02 10:53:08.747618	2026-04-02 10:53:08.747618
2	개발팀	기능 개발, 버그 수정	t	2026-04-02 10:53:08.747618	2026-04-02 10:53:08.747618
3	운영팀	일반 문의 및 사용자 지원	t	2026-04-02 10:53:08.747618	2026-04-02 10:53:08.747618
\.


--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.attachments_id_seq', 1, false);


--
-- Name: channel_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.channel_configs_id_seq', 3, true);


--
-- Name: channel_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.channel_messages_id_seq', 1, false);


--
-- Name: csat_surveys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.csat_surveys_id_seq', 1, false);


--
-- Name: inquiries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.inquiries_id_seq', 8, true);


--
-- Name: inquiry_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.inquiry_messages_id_seq', 10, true);


--
-- Name: knowledge_connectors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.knowledge_connectors_id_seq', 1, false);


--
-- Name: knowledge_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.knowledge_documents_id_seq', 1, false);


--
-- Name: members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.members_id_seq', 3, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.notifications_id_seq', 5, true);


--
-- Name: personal_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.personal_notes_id_seq', 1, false);


--
-- Name: prompt_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.prompt_configs_id_seq', 4, true);


--
-- Name: reply_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.reply_templates_id_seq', 3, true);


--
-- Name: sla_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.sla_rules_id_seq', 4, true);


--
-- Name: task_checklists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.task_checklists_id_seq', 1, false);


--
-- Name: task_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.task_comments_id_seq', 1, false);


--
-- Name: task_guides_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.task_guides_id_seq', 1, false);


--
-- Name: task_holds_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.task_holds_id_seq', 1, false);


--
-- Name: task_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.task_logs_id_seq', 1, false);


--
-- Name: task_relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.task_relations_id_seq', 1, false);


--
-- Name: task_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.task_tags_id_seq', 1, false);


--
-- Name: task_transfers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.task_transfers_id_seq', 1, false);


--
-- Name: task_watchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.task_watchers_id_seq', 1, false);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.tasks_id_seq', 4, true);


--
-- Name: team_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.team_members_id_seq', 1, false);


--
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: breaddesk
--

SELECT pg_catalog.setval('public.teams_id_seq', 3, true);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: channel_configs channel_configs_channel_type_key; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.channel_configs
    ADD CONSTRAINT channel_configs_channel_type_key UNIQUE (channel_type);


--
-- Name: channel_configs channel_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.channel_configs
    ADD CONSTRAINT channel_configs_pkey PRIMARY KEY (id);


--
-- Name: channel_messages channel_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.channel_messages
    ADD CONSTRAINT channel_messages_pkey PRIMARY KEY (id);


--
-- Name: csat_surveys csat_surveys_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.csat_surveys
    ADD CONSTRAINT csat_surveys_pkey PRIMARY KEY (id);


--
-- Name: csat_surveys csat_surveys_token_key; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.csat_surveys
    ADD CONSTRAINT csat_surveys_token_key UNIQUE (token);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: inquiries inquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.inquiries
    ADD CONSTRAINT inquiries_pkey PRIMARY KEY (id);


--
-- Name: inquiry_messages inquiry_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.inquiry_messages
    ADD CONSTRAINT inquiry_messages_pkey PRIMARY KEY (id);


--
-- Name: knowledge_connectors knowledge_connectors_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.knowledge_connectors
    ADD CONSTRAINT knowledge_connectors_pkey PRIMARY KEY (id);


--
-- Name: knowledge_documents knowledge_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.knowledge_documents
    ADD CONSTRAINT knowledge_documents_pkey PRIMARY KEY (id);


--
-- Name: members members_email_key; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_email_key UNIQUE (email);


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: personal_notes personal_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.personal_notes
    ADD CONSTRAINT personal_notes_pkey PRIMARY KEY (id);


--
-- Name: prompt_configs prompt_configs_key_key; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.prompt_configs
    ADD CONSTRAINT prompt_configs_key_key UNIQUE (key);


--
-- Name: prompt_configs prompt_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.prompt_configs
    ADD CONSTRAINT prompt_configs_pkey PRIMARY KEY (id);


--
-- Name: reply_templates reply_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.reply_templates
    ADD CONSTRAINT reply_templates_pkey PRIMARY KEY (id);


--
-- Name: sla_rules sla_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.sla_rules
    ADD CONSTRAINT sla_rules_pkey PRIMARY KEY (id);


--
-- Name: sla_rules sla_rules_urgency_key; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.sla_rules
    ADD CONSTRAINT sla_rules_urgency_key UNIQUE (urgency);


--
-- Name: task_checklists task_checklists_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_checklists
    ADD CONSTRAINT task_checklists_pkey PRIMARY KEY (id);


--
-- Name: task_comments task_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_pkey PRIMARY KEY (id);


--
-- Name: task_guides task_guides_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_guides
    ADD CONSTRAINT task_guides_pkey PRIMARY KEY (id);


--
-- Name: task_holds task_holds_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_holds
    ADD CONSTRAINT task_holds_pkey PRIMARY KEY (id);


--
-- Name: task_logs task_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_logs
    ADD CONSTRAINT task_logs_pkey PRIMARY KEY (id);


--
-- Name: task_relations task_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_relations
    ADD CONSTRAINT task_relations_pkey PRIMARY KEY (id);


--
-- Name: task_tags task_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT task_tags_pkey PRIMARY KEY (id);


--
-- Name: task_transfers task_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_transfers
    ADD CONSTRAINT task_transfers_pkey PRIMARY KEY (id);


--
-- Name: task_watchers task_watchers_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_watchers
    ADD CONSTRAINT task_watchers_pkey PRIMARY KEY (id);


--
-- Name: task_watchers task_watchers_task_id_member_id_key; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_watchers
    ADD CONSTRAINT task_watchers_task_id_member_id_key UNIQUE (task_id, member_id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_team_id_member_id_key; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_team_id_member_id_key UNIQUE (team_id, member_id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: idx_attachments_entity; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_attachments_entity ON public.attachments USING btree (entity_type, entity_id);


--
-- Name: idx_channel_configs_active; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_channel_configs_active ON public.channel_configs USING btree (is_active);


--
-- Name: idx_channel_configs_type; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_channel_configs_type ON public.channel_configs USING btree (channel_type);


--
-- Name: idx_channel_messages_channel_type; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_channel_messages_channel_type ON public.channel_messages USING btree (channel_type);


--
-- Name: idx_channel_messages_inquiry_id; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_channel_messages_inquiry_id ON public.channel_messages USING btree (inquiry_id);


--
-- Name: idx_channel_messages_processed; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_channel_messages_processed ON public.channel_messages USING btree (processed, created_at);


--
-- Name: idx_csat_surveys_inquiry_id; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_csat_surveys_inquiry_id ON public.csat_surveys USING btree (inquiry_id);


--
-- Name: idx_csat_surveys_responded; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_csat_surveys_responded ON public.csat_surveys USING btree (responded);


--
-- Name: idx_csat_surveys_token; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_csat_surveys_token ON public.csat_surveys USING btree (token);


--
-- Name: idx_inquiries_team_id; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_inquiries_team_id ON public.inquiries USING btree (team_id);


--
-- Name: idx_inquiry_messages_sentiment; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_inquiry_messages_sentiment ON public.inquiry_messages USING btree (sentiment);


--
-- Name: idx_knowledge_documents_source_source_id; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_knowledge_documents_source_source_id ON public.knowledge_documents USING btree (source, source_id);


--
-- Name: idx_knowledge_source; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_knowledge_source ON public.knowledge_documents USING btree (source, source_id);


--
-- Name: idx_notifications_member; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_notifications_member ON public.notifications USING btree (member_id, is_read);


--
-- Name: idx_prompt_configs_active; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_prompt_configs_active ON public.prompt_configs USING btree (active);


--
-- Name: idx_prompt_configs_key; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_prompt_configs_key ON public.prompt_configs USING btree (key);


--
-- Name: idx_task_logs_task; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_task_logs_task ON public.task_logs USING btree (task_id);


--
-- Name: idx_task_tags_tag; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_task_tags_tag ON public.task_tags USING btree (tag);


--
-- Name: idx_tasks_team_id; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_tasks_team_id ON public.tasks USING btree (team_id);


--
-- Name: idx_team_members_member_id; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_team_members_member_id ON public.team_members USING btree (member_id);


--
-- Name: idx_team_members_team_id; Type: INDEX; Schema: public; Owner: breaddesk
--

CREATE INDEX idx_team_members_team_id ON public.team_members USING btree (team_id);


--
-- Name: attachments attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.members(id) ON DELETE SET NULL;


--
-- Name: channel_messages channel_messages_inquiry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.channel_messages
    ADD CONSTRAINT channel_messages_inquiry_id_fkey FOREIGN KEY (inquiry_id) REFERENCES public.inquiries(id) ON DELETE SET NULL;


--
-- Name: csat_surveys csat_surveys_inquiry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.csat_surveys
    ADD CONSTRAINT csat_surveys_inquiry_id_fkey FOREIGN KEY (inquiry_id) REFERENCES public.inquiries(id) ON DELETE CASCADE;


--
-- Name: inquiries fk_inquiry_task; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.inquiries
    ADD CONSTRAINT fk_inquiry_task FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: inquiries inquiries_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.inquiries
    ADD CONSTRAINT inquiries_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE SET NULL;


--
-- Name: inquiry_messages inquiry_messages_inquiry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.inquiry_messages
    ADD CONSTRAINT inquiry_messages_inquiry_id_fkey FOREIGN KEY (inquiry_id) REFERENCES public.inquiries(id) ON DELETE CASCADE;


--
-- Name: knowledge_documents knowledge_documents_connector_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.knowledge_documents
    ADD CONSTRAINT knowledge_documents_connector_id_fkey FOREIGN KEY (connector_id) REFERENCES public.knowledge_connectors(id);


--
-- Name: notifications notifications_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: personal_notes personal_notes_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.personal_notes
    ADD CONSTRAINT personal_notes_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: reply_templates reply_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.reply_templates
    ADD CONSTRAINT reply_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.members(id) ON DELETE SET NULL;


--
-- Name: task_checklists task_checklists_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_checklists
    ADD CONSTRAINT task_checklists_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_comments task_comments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.members(id) ON DELETE SET NULL;


--
-- Name: task_comments task_comments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_guides task_guides_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_guides
    ADD CONSTRAINT task_guides_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_holds task_holds_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_holds
    ADD CONSTRAINT task_holds_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_logs task_logs_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_logs
    ADD CONSTRAINT task_logs_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.members(id) ON DELETE SET NULL;


--
-- Name: task_logs task_logs_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_logs
    ADD CONSTRAINT task_logs_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_relations task_relations_source_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_relations
    ADD CONSTRAINT task_relations_source_task_id_fkey FOREIGN KEY (source_task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_relations task_relations_target_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_relations
    ADD CONSTRAINT task_relations_target_task_id_fkey FOREIGN KEY (target_task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_tags task_tags_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT task_tags_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_transfers task_transfers_from_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_transfers
    ADD CONSTRAINT task_transfers_from_member_id_fkey FOREIGN KEY (from_member_id) REFERENCES public.members(id) ON DELETE SET NULL;


--
-- Name: task_transfers task_transfers_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_transfers
    ADD CONSTRAINT task_transfers_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_transfers task_transfers_to_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_transfers
    ADD CONSTRAINT task_transfers_to_member_id_fkey FOREIGN KEY (to_member_id) REFERENCES public.members(id) ON DELETE SET NULL;


--
-- Name: task_watchers task_watchers_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_watchers
    ADD CONSTRAINT task_watchers_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: task_watchers task_watchers_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.task_watchers
    ADD CONSTRAINT task_watchers_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.members(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_inquiry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_inquiry_id_fkey FOREIGN KEY (inquiry_id) REFERENCES public.inquiries(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE SET NULL;


--
-- Name: team_members team_members_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: team_members team_members_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: breaddesk
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict hx5ucWq64tIXNf5akPG9OwIm46jEDoRV7btIvLktyPVo6xTLueEztlSIkdzdS5W

